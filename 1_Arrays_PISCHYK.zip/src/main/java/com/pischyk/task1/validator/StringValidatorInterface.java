package com.pischyk.task1.validator;

public interface StringValidatorInterface {

    public boolean isValid(String str);
}
