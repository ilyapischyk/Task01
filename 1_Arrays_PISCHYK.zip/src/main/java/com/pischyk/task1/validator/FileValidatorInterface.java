package com.pischyk.task1.validator;

import java.io.File;

public interface FileValidatorInterface {

    public boolean isValid(File file);
}
