package com.pischyk.task1.parser;

import java.util.ArrayList;

public interface StringParserInterface {
    public int[] parseString(ArrayList<String> arrayList);
}
